require "rails"

module Questionnaire
  class Engine < Rails::Engine
  end
end
